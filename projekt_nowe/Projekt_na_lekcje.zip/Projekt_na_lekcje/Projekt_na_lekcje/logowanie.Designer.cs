﻿
namespace Projekt_na_lekcje
{
    partial class logowanie
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.l_login = new System.Windows.Forms.TextBox();
            this.l_zaloguj = new System.Windows.Forms.Button();
            this.l_zarejestruj = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.l_haslo = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(155, 93);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(109, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Podaj swój login";
            // 
            // l_login
            // 
            this.l_login.Location = new System.Drawing.Point(376, 90);
            this.l_login.Name = "l_login";
            this.l_login.Size = new System.Drawing.Size(178, 22);
            this.l_login.TabIndex = 1;
            this.l_login.TextChanged += new System.EventHandler(this.l_login_TextChanged);
            // 
            // l_zaloguj
            // 
            this.l_zaloguj.Location = new System.Drawing.Point(529, 292);
            this.l_zaloguj.Name = "l_zaloguj";
            this.l_zaloguj.Size = new System.Drawing.Size(147, 40);
            this.l_zaloguj.TabIndex = 2;
            this.l_zaloguj.Text = "Zaloguj";
            this.l_zaloguj.UseVisualStyleBackColor = true;
            this.l_zaloguj.Click += new System.EventHandler(this.l_zaloguj_Click);
            // 
            // l_zarejestruj
            // 
            this.l_zarejestruj.Location = new System.Drawing.Point(327, 292);
            this.l_zarejestruj.Name = "l_zarejestruj";
            this.l_zarejestruj.Size = new System.Drawing.Size(178, 40);
            this.l_zarejestruj.TabIndex = 3;
            this.l_zarejestruj.Text = "nie masz jeszcze konta?";
            this.l_zarejestruj.UseVisualStyleBackColor = true;
            this.l_zarejestruj.Click += new System.EventHandler(this.button2_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(155, 138);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(121, 17);
            this.label2.TabIndex = 4;
            this.label2.Text = "Podaj swoje hasło";
            // 
            // l_haslo
            // 
            this.l_haslo.Location = new System.Drawing.Point(376, 138);
            this.l_haslo.Name = "l_haslo";
            this.l_haslo.Size = new System.Drawing.Size(178, 22);
            this.l_haslo.TabIndex = 5;
            this.l_haslo.TextChanged += new System.EventHandler(this.l_haslo_TextChanged);
            // 
            // logowanie
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(688, 344);
            this.Controls.Add(this.l_haslo);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.l_zarejestruj);
            this.Controls.Add(this.l_zaloguj);
            this.Controls.Add(this.l_login);
            this.Controls.Add(this.label1);
            this.Name = "logowanie";
            this.Text = "logowanie";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox l_login;
        private System.Windows.Forms.Button l_zaloguj;
        private System.Windows.Forms.Button l_zarejestruj;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox l_haslo;
    }
}