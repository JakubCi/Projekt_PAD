﻿
namespace Projekt_na_lekcje
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea10 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend10 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series10 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.Pozostale_P = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.Budzet = new System.Windows.Forms.TextBox();
            this.Wykres_Wydatki = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.button3 = new System.Windows.Forms.Button();
            this.p_saldo = new System.Windows.Forms.Label();
            this.p_oszczednosci_miesieczne = new System.Windows.Forms.Label();
            this.p_wydatki_miesieczne = new System.Windows.Forms.Label();
            this.p_przychod_miesieczny = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.W_stale = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.Wyczysc = new System.Windows.Forms.Button();
            this.W_Sprzet = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.W_Pracownicy = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.W_Nieplanowane = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.tabControl3 = new System.Windows.Forms.TabControl();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.button1 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.k_ulga = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.k_koszty = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.k_zl = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.k_kwota = new System.Windows.Forms.ComboBox();
            this.tabPage9 = new System.Windows.Forms.TabPage();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.listView1 = new System.Windows.Forms.ListView();
            this.l_imie = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.l_nazwisko = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.l_posada = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.l_wynagrodzenie = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.l_numer = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.d_wynagrodzenie = new System.Windows.Forms.TextBox();
            this.d_posada = new System.Windows.Forms.TextBox();
            this.d_nazwisko = new System.Windows.Forms.TextBox();
            this.d_imie = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.button7 = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button8 = new System.Windows.Forms.Button();
            this.label23 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.tabControl4 = new System.Windows.Forms.TabControl();
            this.tabPage10 = new System.Windows.Forms.TabPage();
            this.tabPage11 = new System.Windows.Forms.TabPage();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.vat_button = new System.Windows.Forms.Button();
            this.vat_stawka = new System.Windows.Forms.ComboBox();
            this.vat_zl = new System.Windows.Forms.TextBox();
            this.vat_kwota = new System.Windows.Forms.ComboBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.button9 = new System.Windows.Forms.Button();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.button10 = new System.Windows.Forms.Button();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.listView2 = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Wykres_Wydatki)).BeginInit();
            this.tabPage5.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.tabControl3.SuspendLayout();
            this.tabPage8.SuspendLayout();
            this.tabPage9.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tabControl4.SuspendLayout();
            this.tabPage10.SuspendLayout();
            this.tabPage11.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.tabControl1.Location = new System.Drawing.Point(3, 2);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1071, 513);
            this.tabControl1.TabIndex = 7;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.PowderBlue;
            this.tabPage1.Controls.Add(this.Pozostale_P);
            this.tabPage1.Controls.Add(this.label14);
            this.tabPage1.Controls.Add(this.Budzet);
            this.tabPage1.Controls.Add(this.Wykres_Wydatki);
            this.tabPage1.Controls.Add(this.button3);
            this.tabPage1.Controls.Add(this.p_saldo);
            this.tabPage1.Controls.Add(this.p_oszczednosci_miesieczne);
            this.tabPage1.Controls.Add(this.p_wydatki_miesieczne);
            this.tabPage1.Controls.Add(this.p_przychod_miesieczny);
            this.tabPage1.Controls.Add(this.label10);
            this.tabPage1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage1.Size = new System.Drawing.Size(1063, 484);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Obrót Firmy";
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            this.tabPage1.Enter += new System.EventHandler(this.tabPage1_Click);
            // 
            // Pozostale_P
            // 
            this.Pozostale_P.AutoSize = true;
            this.Pozostale_P.Font = new System.Drawing.Font("Sitka Subheading", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Pozostale_P.Location = new System.Drawing.Point(761, 279);
            this.Pozostale_P.Name = "Pozostale_P";
            this.Pozostale_P.Size = new System.Drawing.Size(24, 40);
            this.Pozostale_P.TabIndex = 26;
            this.Pozostale_P.Text = " ";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Sitka Subheading", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label14.Location = new System.Drawing.Point(559, 207);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(402, 40);
            this.label14.TabIndex = 25;
            this.label14.Text = "W tym miesiącu Pozostanie ci";
            // 
            // Budzet
            // 
            this.Budzet.Location = new System.Drawing.Point(649, 153);
            this.Budzet.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Budzet.Name = "Budzet";
            this.Budzet.Size = new System.Drawing.Size(255, 24);
            this.Budzet.TabIndex = 24;
            this.Budzet.TextChanged += new System.EventHandler(this.Budzet_TextChanged);
            // 
            // Wykres_Wydatki
            // 
            this.Wykres_Wydatki.BackColor = System.Drawing.Color.Transparent;
            this.Wykres_Wydatki.BorderlineColor = System.Drawing.Color.Transparent;
            chartArea10.BackColor = System.Drawing.Color.Transparent;
            chartArea10.Name = "ChartArea1";
            this.Wykres_Wydatki.ChartAreas.Add(chartArea10);
            legend10.BackColor = System.Drawing.Color.Transparent;
            legend10.BackImageTransparentColor = System.Drawing.Color.Transparent;
            legend10.Name = "Legend1";
            legend10.TitleBackColor = System.Drawing.Color.Transparent;
            this.Wykres_Wydatki.Legends.Add(legend10);
            this.Wykres_Wydatki.Location = new System.Drawing.Point(-11, 63);
            this.Wykres_Wydatki.Margin = new System.Windows.Forms.Padding(4);
            this.Wykres_Wydatki.MaximumSize = new System.Drawing.Size(605, 369);
            this.Wykres_Wydatki.MinimumSize = new System.Drawing.Size(605, 369);
            this.Wykres_Wydatki.Name = "Wykres_Wydatki";
            this.Wykres_Wydatki.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Berry;
            series10.BackSecondaryColor = System.Drawing.Color.Transparent;
            series10.BorderColor = System.Drawing.Color.Transparent;
            series10.ChartArea = "ChartArea1";
            series10.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Pie;
            series10.Color = System.Drawing.Color.Transparent;
            series10.LabelBackColor = System.Drawing.Color.Transparent;
            series10.Legend = "Legend1";
            series10.MarkerBorderColor = System.Drawing.Color.Transparent;
            series10.MarkerColor = System.Drawing.Color.Transparent;
            series10.Name = "Wydatki";
            this.Wykres_Wydatki.Series.Add(series10);
            this.Wykres_Wydatki.Size = new System.Drawing.Size(605, 369);
            this.Wykres_Wydatki.TabIndex = 23;
            this.Wykres_Wydatki.Text = "chart1";
            this.Wykres_Wydatki.Click += new System.EventHandler(this.Wykres_Wydatki_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(675, 345);
            this.button3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(213, 63);
            this.button3.TabIndex = 22;
            this.button3.Text = "Zapisz";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // p_saldo
            // 
            this.p_saldo.AutoSize = true;
            this.p_saldo.Font = new System.Drawing.Font("Sitka Subheading", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.p_saldo.Location = new System.Drawing.Point(619, 341);
            this.p_saldo.Name = "p_saldo";
            this.p_saldo.Size = new System.Drawing.Size(0, 29);
            this.p_saldo.TabIndex = 21;
            // 
            // p_oszczednosci_miesieczne
            // 
            this.p_oszczednosci_miesieczne.AutoSize = true;
            this.p_oszczednosci_miesieczne.Font = new System.Drawing.Font("Sitka Subheading", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.p_oszczednosci_miesieczne.Location = new System.Drawing.Point(619, 246);
            this.p_oszczednosci_miesieczne.Name = "p_oszczednosci_miesieczne";
            this.p_oszczednosci_miesieczne.Size = new System.Drawing.Size(0, 29);
            this.p_oszczednosci_miesieczne.TabIndex = 20;
            // 
            // p_wydatki_miesieczne
            // 
            this.p_wydatki_miesieczne.AutoSize = true;
            this.p_wydatki_miesieczne.Font = new System.Drawing.Font("Sitka Subheading", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.p_wydatki_miesieczne.Location = new System.Drawing.Point(619, 150);
            this.p_wydatki_miesieczne.Name = "p_wydatki_miesieczne";
            this.p_wydatki_miesieczne.Size = new System.Drawing.Size(0, 29);
            this.p_wydatki_miesieczne.TabIndex = 19;
            // 
            // p_przychod_miesieczny
            // 
            this.p_przychod_miesieczny.AutoSize = true;
            this.p_przychod_miesieczny.Font = new System.Drawing.Font("Sitka Subheading", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.p_przychod_miesieczny.Location = new System.Drawing.Point(619, 63);
            this.p_przychod_miesieczny.Name = "p_przychod_miesieczny";
            this.p_przychod_miesieczny.Size = new System.Drawing.Size(0, 29);
            this.p_przychod_miesieczny.TabIndex = 18;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Sitka Subheading", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label10.Location = new System.Drawing.Point(616, 63);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(300, 40);
            this.label10.TabIndex = 16;
            this.label10.Text = "Budżet na ten miesiąc";
            // 
            // tabPage5
            // 
            this.tabPage5.BackColor = System.Drawing.Color.PowderBlue;
            this.tabPage5.Controls.Add(this.W_stale);
            this.tabPage5.Controls.Add(this.label13);
            this.tabPage5.Controls.Add(this.Wyczysc);
            this.tabPage5.Controls.Add(this.W_Sprzet);
            this.tabPage5.Controls.Add(this.label11);
            this.tabPage5.Controls.Add(this.W_Pracownicy);
            this.tabPage5.Controls.Add(this.label12);
            this.tabPage5.Controls.Add(this.button2);
            this.tabPage5.Controls.Add(this.W_Nieplanowane);
            this.tabPage5.Controls.Add(this.label15);
            this.tabPage5.Location = new System.Drawing.Point(4, 25);
            this.tabPage5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage5.Size = new System.Drawing.Size(1063, 484);
            this.tabPage5.TabIndex = 2;
            this.tabPage5.Text = "Wpisz dane";
            // 
            // W_stale
            // 
            this.W_stale.Location = new System.Drawing.Point(581, 263);
            this.W_stale.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.W_stale.Name = "W_stale";
            this.W_stale.Size = new System.Drawing.Size(339, 22);
            this.W_stale.TabIndex = 18;
            this.W_stale.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Sitka Subheading", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label13.Location = new System.Drawing.Point(5, 250);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(197, 40);
            this.label13.TabIndex = 17;
            this.label13.Text = "Wydatki Stałe";
            this.label13.Click += new System.EventHandler(this.label13_Click);
            // 
            // Wyczysc
            // 
            this.Wyczysc.Location = new System.Drawing.Point(621, 410);
            this.Wyczysc.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Wyczysc.Name = "Wyczysc";
            this.Wyczysc.Size = new System.Drawing.Size(213, 63);
            this.Wyczysc.TabIndex = 16;
            this.Wyczysc.Text = "Wyczyść";
            this.Wyczysc.UseVisualStyleBackColor = true;
            // 
            // W_Sprzet
            // 
            this.W_Sprzet.Location = new System.Drawing.Point(581, 191);
            this.W_Sprzet.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.W_Sprzet.Name = "W_Sprzet";
            this.W_Sprzet.Size = new System.Drawing.Size(339, 22);
            this.W_Sprzet.TabIndex = 15;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Sitka Subheading", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label11.Location = new System.Drawing.Point(5, 107);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(404, 40);
            this.label11.TabIndex = 14;
            this.label11.Text = "Wynagrodzenia Pracowników";
            // 
            // W_Pracownicy
            // 
            this.W_Pracownicy.Location = new System.Drawing.Point(581, 122);
            this.W_Pracownicy.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.W_Pracownicy.Name = "W_Pracownicy";
            this.W_Pracownicy.Size = new System.Drawing.Size(339, 22);
            this.W_Pracownicy.TabIndex = 13;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Sitka Subheading", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label12.Location = new System.Drawing.Point(3, 47);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(447, 40);
            this.label12.TabIndex = 12;
            this.label12.Text = "Budżet na nieplanowane wydatki";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(840, 410);
            this.button2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(213, 63);
            this.button2.TabIndex = 11;
            this.button2.Text = "Podsumujmy";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click_2);
            // 
            // W_Nieplanowane
            // 
            this.W_Nieplanowane.Location = new System.Drawing.Point(581, 47);
            this.W_Nieplanowane.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.W_Nieplanowane.Name = "W_Nieplanowane";
            this.W_Nieplanowane.Size = new System.Drawing.Size(339, 22);
            this.W_Nieplanowane.TabIndex = 10;
            this.W_Nieplanowane.TextChanged += new System.EventHandler(this.zarobki_TextChanged);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Sitka Subheading", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label15.Location = new System.Drawing.Point(5, 176);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(232, 40);
            this.label15.TabIndex = 9;
            this.label15.Text = "Koszta na sprzęt";
            this.label15.Click += new System.EventHandler(this.label15_Click);
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabPage4);
            this.tabControl2.Controls.Add(this.tabPage6);
            this.tabControl2.Controls.Add(this.tabPage3);
            this.tabControl2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl2.Location = new System.Drawing.Point(0, 0);
            this.tabControl2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(1085, 546);
            this.tabControl2.TabIndex = 9;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.tabControl1);
            this.tabPage4.Location = new System.Drawing.Point(4, 25);
            this.tabPage4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage4.Size = new System.Drawing.Size(1077, 517);
            this.tabPage4.TabIndex = 0;
            this.tabPage4.Text = "Przychód";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // tabPage6
            // 
            this.tabPage6.BackColor = System.Drawing.Color.PowderBlue;
            this.tabPage6.Controls.Add(this.tabControl3);
            this.tabPage6.Location = new System.Drawing.Point(4, 25);
            this.tabPage6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage6.Size = new System.Drawing.Size(1077, 517);
            this.tabPage6.TabIndex = 2;
            this.tabPage6.Text = "Pracownicy";
            this.tabPage6.Click += new System.EventHandler(this.tabPage6_Click);
            // 
            // tabControl3
            // 
            this.tabControl3.Controls.Add(this.tabPage8);
            this.tabControl3.Controls.Add(this.tabPage9);
            this.tabControl3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl3.Location = new System.Drawing.Point(3, 2);
            this.tabControl3.Name = "tabControl3";
            this.tabControl3.SelectedIndex = 0;
            this.tabControl3.Size = new System.Drawing.Size(1071, 513);
            this.tabControl3.TabIndex = 0;
            // 
            // tabPage8
            // 
            this.tabPage8.BackColor = System.Drawing.Color.PowderBlue;
            this.tabPage8.Controls.Add(this.button1);
            this.tabPage8.Controls.Add(this.label2);
            this.tabPage8.Controls.Add(this.label3);
            this.tabPage8.Controls.Add(this.k_ulga);
            this.tabPage8.Controls.Add(this.label5);
            this.tabPage8.Controls.Add(this.k_koszty);
            this.tabPage8.Controls.Add(this.label4);
            this.tabPage8.Controls.Add(this.k_zl);
            this.tabPage8.Controls.Add(this.label1);
            this.tabPage8.Controls.Add(this.k_kwota);
            this.tabPage8.Location = new System.Drawing.Point(4, 25);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage8.Size = new System.Drawing.Size(1063, 484);
            this.tabPage8.TabIndex = 0;
            this.tabPage8.Text = "Kalkulator Wynagrodzen pracownika";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(389, 384);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(255, 62);
            this.button1.TabIndex = 23;
            this.button1.Text = "Oblicz";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Sitka Subheading", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.Location = new System.Drawing.Point(335, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(84, 40);
            this.label2.TabIndex = 22;
            this.label2.Text = "Złoty";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label3.Location = new System.Drawing.Point(677, 78);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(349, 39);
            this.label3.TabIndex = 21;
            this.label3.Text = "Wynagrodzenie brutto";
            // 
            // k_ulga
            // 
            this.k_ulga.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.k_ulga.FormattingEnabled = true;
            this.k_ulga.Items.AddRange(new object[] {
            "Brak",
            "Pojedyńcza",
            "Podwójna"});
            this.k_ulga.Location = new System.Drawing.Point(467, 291);
            this.k_ulga.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.k_ulga.Name = "k_ulga";
            this.k_ulga.Size = new System.Drawing.Size(191, 24);
            this.k_ulga.TabIndex = 20;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Sitka Subheading", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label5.Location = new System.Drawing.Point(114, 276);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(310, 40);
            this.label5.TabIndex = 19;
            this.label5.Text = "Ulga dla klasy średniej";
            // 
            // k_koszty
            // 
            this.k_koszty.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.k_koszty.FormattingEnabled = true;
            this.k_koszty.Items.AddRange(new object[] {
            "Zwykłe",
            "Podwyższone"});
            this.k_koszty.Location = new System.Drawing.Point(467, 201);
            this.k_koszty.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.k_koszty.Name = "k_koszty";
            this.k_koszty.Size = new System.Drawing.Size(191, 24);
            this.k_koszty.TabIndex = 18;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Sitka Subheading", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label4.Location = new System.Drawing.Point(26, 186);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(408, 40);
            this.label4.TabIndex = 17;
            this.label4.Text = "Koszty uzyskanie przychodów";
            // 
            // k_zl
            // 
            this.k_zl.Location = new System.Drawing.Point(467, 35);
            this.k_zl.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.k_zl.Name = "k_zl";
            this.k_zl.Size = new System.Drawing.Size(191, 22);
            this.k_zl.TabIndex = 16;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Sitka Subheading", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(319, 97);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(96, 39);
            this.label1.TabIndex = 15;
            this.label1.Text = "Kwota";
            // 
            // k_kwota
            // 
            this.k_kwota.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.k_kwota.FormattingEnabled = true;
            this.k_kwota.Items.AddRange(new object[] {
            "Brutto",
            "Netto"});
            this.k_kwota.Location = new System.Drawing.Point(467, 112);
            this.k_kwota.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.k_kwota.Name = "k_kwota";
            this.k_kwota.Size = new System.Drawing.Size(191, 24);
            this.k_kwota.TabIndex = 14;
            // 
            // tabPage9
            // 
            this.tabPage9.BackColor = System.Drawing.Color.PowderBlue;
            this.tabPage9.Controls.Add(this.groupBox2);
            this.tabPage9.Controls.Add(this.groupBox1);
            this.tabPage9.Controls.Add(this.button5);
            this.tabPage9.Controls.Add(this.button4);
            this.tabPage9.Controls.Add(this.listView1);
            this.tabPage9.Location = new System.Drawing.Point(4, 25);
            this.tabPage9.Name = "tabPage9";
            this.tabPage9.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage9.Size = new System.Drawing.Size(1063, 484);
            this.tabPage9.TabIndex = 1;
            this.tabPage9.Text = "pracownicy";
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(594, 427);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(182, 40);
            this.button5.TabIndex = 2;
            this.button5.Text = "Usuń pracownika";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(294, 427);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(182, 40);
            this.button4.TabIndex = 1;
            this.button4.Text = "Dodaj pracownika";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // listView1
            // 
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.l_imie,
            this.l_nazwisko,
            this.l_posada,
            this.l_wynagrodzenie,
            this.l_numer});
            this.listView1.HideSelection = false;
            this.listView1.LabelEdit = true;
            this.listView1.Location = new System.Drawing.Point(6, 6);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(692, 405);
            this.listView1.TabIndex = 0;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            this.listView1.SelectedIndexChanged += new System.EventHandler(this.listView1_SelectedIndexChanged);
            // 
            // l_imie
            // 
            this.l_imie.Text = "Imię";
            this.l_imie.Width = 141;
            // 
            // l_nazwisko
            // 
            this.l_nazwisko.Text = "Nazwisko";
            this.l_nazwisko.Width = 182;
            // 
            // l_posada
            // 
            this.l_posada.Text = "Posada";
            this.l_posada.Width = 164;
            // 
            // l_wynagrodzenie
            // 
            this.l_wynagrodzenie.Text = "Wynagrodzenie";
            this.l_wynagrodzenie.Width = 110;
            // 
            // l_numer
            // 
            this.l_numer.Text = "Numer";
            this.l_numer.Width = 432;
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.PowderBlue;
            this.tabPage3.Controls.Add(this.tabControl4);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage3.Size = new System.Drawing.Size(1077, 517);
            this.tabPage3.TabIndex = 4;
            this.tabPage3.Text = "Produkty";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button7);
            this.groupBox1.Controls.Add(this.d_wynagrodzenie);
            this.groupBox1.Controls.Add(this.d_posada);
            this.groupBox1.Controls.Add(this.d_nazwisko);
            this.groupBox1.Controls.Add(this.d_imie);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.label18);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Location = new System.Drawing.Point(704, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(353, 411);
            this.groupBox1.TabIndex = 33;
            this.groupBox1.TabStop = false;
            this.groupBox1.Visible = false;
            // 
            // d_wynagrodzenie
            // 
            this.d_wynagrodzenie.Location = new System.Drawing.Point(210, 269);
            this.d_wynagrodzenie.Name = "d_wynagrodzenie";
            this.d_wynagrodzenie.Size = new System.Drawing.Size(100, 22);
            this.d_wynagrodzenie.TabIndex = 40;
            // 
            // d_posada
            // 
            this.d_posada.Location = new System.Drawing.Point(209, 199);
            this.d_posada.Name = "d_posada";
            this.d_posada.Size = new System.Drawing.Size(100, 22);
            this.d_posada.TabIndex = 39;
            // 
            // d_nazwisko
            // 
            this.d_nazwisko.Location = new System.Drawing.Point(209, 125);
            this.d_nazwisko.Name = "d_nazwisko";
            this.d_nazwisko.Size = new System.Drawing.Size(100, 22);
            this.d_nazwisko.TabIndex = 38;
            // 
            // d_imie
            // 
            this.d_imie.Location = new System.Drawing.Point(209, 58);
            this.d_imie.Name = "d_imie";
            this.d_imie.Size = new System.Drawing.Size(100, 22);
            this.d_imie.TabIndex = 37;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Sitka Subheading", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label16.Location = new System.Drawing.Point(8, 259);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(196, 35);
            this.label16.TabIndex = 36;
            this.label16.Text = "Wynagrodzenie:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Sitka Subheading", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label17.Location = new System.Drawing.Point(7, 189);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(101, 35);
            this.label17.TabIndex = 35;
            this.label17.Text = "Posada:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Sitka Subheading", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label18.Location = new System.Drawing.Point(8, 115);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(130, 35);
            this.label18.TabIndex = 34;
            this.label18.Text = "Nazwisko:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Sitka Subheading", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label19.Location = new System.Drawing.Point(8, 45);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(73, 35);
            this.label19.TabIndex = 33;
            this.label19.Text = "Imię:";
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(107, 352);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(126, 40);
            this.button7.TabIndex = 34;
            this.button7.Text = "Dodaj";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.button8);
            this.groupBox2.Controls.Add(this.textBox4);
            this.groupBox2.Controls.Add(this.label23);
            this.groupBox2.Location = new System.Drawing.Point(704, 0);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(359, 411);
            this.groupBox2.TabIndex = 41;
            this.groupBox2.TabStop = false;
            this.groupBox2.Visible = false;
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(107, 352);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(126, 40);
            this.button8.TabIndex = 34;
            this.button8.Text = "Usuń";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Sitka Subheading", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label23.Location = new System.Drawing.Point(52, 115);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(236, 35);
            this.label23.TabIndex = 33;
            this.label23.Text = "Numer pracownika:";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(114, 171);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(100, 22);
            this.textBox4.TabIndex = 37;
            this.textBox4.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // tabControl4
            // 
            this.tabControl4.Controls.Add(this.tabPage10);
            this.tabControl4.Controls.Add(this.tabPage11);
            this.tabControl4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl4.Location = new System.Drawing.Point(3, 2);
            this.tabControl4.Name = "tabControl4";
            this.tabControl4.SelectedIndex = 0;
            this.tabControl4.Size = new System.Drawing.Size(1071, 513);
            this.tabControl4.TabIndex = 0;
            // 
            // tabPage10
            // 
            this.tabPage10.BackColor = System.Drawing.Color.PowderBlue;
            this.tabPage10.Controls.Add(this.label6);
            this.tabPage10.Controls.Add(this.label7);
            this.tabPage10.Controls.Add(this.label8);
            this.tabPage10.Controls.Add(this.label9);
            this.tabPage10.Controls.Add(this.vat_button);
            this.tabPage10.Controls.Add(this.vat_stawka);
            this.tabPage10.Controls.Add(this.vat_zl);
            this.tabPage10.Controls.Add(this.vat_kwota);
            this.tabPage10.Location = new System.Drawing.Point(4, 25);
            this.tabPage10.Name = "tabPage10";
            this.tabPage10.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage10.Size = new System.Drawing.Size(1063, 484);
            this.tabPage10.TabIndex = 0;
            this.tabPage10.Text = "Kalkulator podatku vat";
            // 
            // tabPage11
            // 
            this.tabPage11.BackColor = System.Drawing.Color.PowderBlue;
            this.tabPage11.Controls.Add(this.groupBox3);
            this.tabPage11.Controls.Add(this.groupBox4);
            this.tabPage11.Controls.Add(this.button11);
            this.tabPage11.Controls.Add(this.button12);
            this.tabPage11.Controls.Add(this.listView2);
            this.tabPage11.Location = new System.Drawing.Point(4, 25);
            this.tabPage11.Name = "tabPage11";
            this.tabPage11.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage11.Size = new System.Drawing.Size(1063, 484);
            this.tabPage11.TabIndex = 1;
            this.tabPage11.Text = "Lista produktów";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Sitka Subheading", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label6.Location = new System.Drawing.Point(237, 17);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(84, 40);
            this.label6.TabIndex = 31;
            this.label6.Text = "Złoty";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Sitka Subheading", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label7.Location = new System.Drawing.Point(166, 181);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(161, 40);
            this.label7.TabIndex = 30;
            this.label7.Text = "Stawka vat";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Sitka Subheading", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(222, 94);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(96, 39);
            this.label8.TabIndex = 29;
            this.label8.Text = "Kwota";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label9.Location = new System.Drawing.Point(713, 18);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(112, 39);
            this.label9.TabIndex = 28;
            this.label9.Text = "Kwota";
            // 
            // vat_button
            // 
            this.vat_button.Location = new System.Drawing.Point(424, 362);
            this.vat_button.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.vat_button.Name = "vat_button";
            this.vat_button.Size = new System.Drawing.Size(255, 62);
            this.vat_button.TabIndex = 27;
            this.vat_button.Text = "Oblicz";
            this.vat_button.UseVisualStyleBackColor = true;
            // 
            // vat_stawka
            // 
            this.vat_stawka.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.vat_stawka.FormattingEnabled = true;
            this.vat_stawka.Items.AddRange(new object[] {
            "3%",
            "5%",
            "7%",
            "8%",
            "22%",
            "23%",
            ""});
            this.vat_stawka.Location = new System.Drawing.Point(350, 195);
            this.vat_stawka.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.vat_stawka.Name = "vat_stawka";
            this.vat_stawka.Size = new System.Drawing.Size(191, 24);
            this.vat_stawka.TabIndex = 26;
            // 
            // vat_zl
            // 
            this.vat_zl.Location = new System.Drawing.Point(350, 32);
            this.vat_zl.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.vat_zl.Name = "vat_zl";
            this.vat_zl.Size = new System.Drawing.Size(191, 22);
            this.vat_zl.TabIndex = 25;
            // 
            // vat_kwota
            // 
            this.vat_kwota.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.vat_kwota.FormattingEnabled = true;
            this.vat_kwota.Items.AddRange(new object[] {
            "Brutto",
            "Netto"});
            this.vat_kwota.Location = new System.Drawing.Point(350, 109);
            this.vat_kwota.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.vat_kwota.Name = "vat_kwota";
            this.vat_kwota.Size = new System.Drawing.Size(191, 24);
            this.vat_kwota.TabIndex = 24;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.button9);
            this.groupBox3.Controls.Add(this.textBox5);
            this.groupBox3.Controls.Add(this.label24);
            this.groupBox3.Location = new System.Drawing.Point(701, 0);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(362, 414);
            this.groupBox3.TabIndex = 46;
            this.groupBox3.TabStop = false;
            this.groupBox3.Visible = false;
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(107, 352);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(126, 40);
            this.button9.TabIndex = 34;
            this.button9.Text = "Usuń";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(114, 171);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(100, 22);
            this.textBox5.TabIndex = 37;
            this.textBox5.TextChanged += new System.EventHandler(this.textBox5_TextChanged);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Sitka Subheading", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label24.Location = new System.Drawing.Point(52, 115);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(208, 35);
            this.label24.TabIndex = 33;
            this.label24.Text = "Numer Produktu:";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.button10);
            this.groupBox4.Controls.Add(this.textBox8);
            this.groupBox4.Controls.Add(this.textBox9);
            this.groupBox4.Controls.Add(this.label27);
            this.groupBox4.Controls.Add(this.label28);
            this.groupBox4.Location = new System.Drawing.Point(701, 9);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(353, 405);
            this.groupBox4.TabIndex = 45;
            this.groupBox4.TabStop = false;
            this.groupBox4.Visible = false;
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(107, 352);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(126, 40);
            this.button10.TabIndex = 34;
            this.button10.Text = "Dodaj";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(220, 198);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(100, 22);
            this.textBox8.TabIndex = 38;
            this.textBox8.TextChanged += new System.EventHandler(this.textBox8_TextChanged);
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(220, 131);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(100, 22);
            this.textBox9.TabIndex = 37;
            this.textBox9.TextChanged += new System.EventHandler(this.textBox9_TextChanged);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Sitka Subheading", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label27.Location = new System.Drawing.Point(19, 188);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(77, 35);
            this.label27.TabIndex = 34;
            this.label27.Text = "Cena:";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Sitka Subheading", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label28.Location = new System.Drawing.Point(19, 118);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(112, 35);
            this.label28.TabIndex = 33;
            this.label28.Text = "Produkt:";
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(591, 436);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(182, 40);
            this.button11.TabIndex = 44;
            this.button11.Text = "Usuń produkt";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(291, 436);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(182, 40);
            this.button12.TabIndex = 43;
            this.button12.Text = "Dodaj produkt";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // listView2
            // 
            this.listView2.BackColor = System.Drawing.Color.White;
            this.listView2.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3});
            this.listView2.HideSelection = false;
            this.listView2.LabelEdit = true;
            this.listView2.Location = new System.Drawing.Point(3, 6);
            this.listView2.Name = "listView2";
            this.listView2.Size = new System.Drawing.Size(692, 405);
            this.listView2.TabIndex = 42;
            this.listView2.UseCompatibleStateImageBehavior = false;
            this.listView2.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Produkt";
            this.columnHeader1.Width = 401;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Cena";
            this.columnHeader2.Width = 167;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Numer";
            this.columnHeader3.Width = 79;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(1085, 546);
            this.Controls.Add(this.tabControl2);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form2";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Wykres_Wydatki)).EndInit();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.tabControl2.ResumeLayout(false);
            this.tabPage4.ResumeLayout(false);
            this.tabPage6.ResumeLayout(false);
            this.tabControl3.ResumeLayout(false);
            this.tabPage8.ResumeLayout(false);
            this.tabPage8.PerformLayout();
            this.tabPage9.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.tabControl4.ResumeLayout(false);
            this.tabPage10.ResumeLayout(false);
            this.tabPage10.PerformLayout();
            this.tabPage11.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label p_saldo;
        private System.Windows.Forms.Label p_oszczednosci_miesieczne;
        private System.Windows.Forms.Label p_wydatki_miesieczne;
        private System.Windows.Forms.Label p_przychod_miesieczny;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox W_Nieplanowane;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox W_Sprzet;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox W_Pracownicy;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox W_stale;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button Wyczysc;
        private System.Windows.Forms.DataVisualization.Charting.Chart Wykres_Wydatki;
        private System.Windows.Forms.TextBox Budzet;
        private System.Windows.Forms.Label Pozostale_P;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TabControl tabControl3;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox k_ulga;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox k_koszty;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox k_zl;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox k_kwota;
        private System.Windows.Forms.TabPage tabPage9;
        private System.Windows.Forms.ColumnHeader l_imie;
        private System.Windows.Forms.ColumnHeader l_nazwisko;
        private System.Windows.Forms.ColumnHeader l_posada;
        private System.Windows.Forms.ColumnHeader l_wynagrodzenie;
        private System.Windows.Forms.ColumnHeader l_numer;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        public System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.GroupBox groupBox1;
        public System.Windows.Forms.TextBox d_wynagrodzenie;
        public System.Windows.Forms.TextBox d_posada;
        public System.Windows.Forms.TextBox d_nazwisko;
        public System.Windows.Forms.TextBox d_imie;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button button8;
        public System.Windows.Forms.TextBox textBox1;
        public System.Windows.Forms.TextBox textBox2;
        public System.Windows.Forms.TextBox textBox3;
        public System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TabControl tabControl4;
        private System.Windows.Forms.TabPage tabPage10;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button vat_button;
        private System.Windows.Forms.ComboBox vat_stawka;
        private System.Windows.Forms.TextBox vat_zl;
        private System.Windows.Forms.ComboBox vat_kwota;
        private System.Windows.Forms.TabPage tabPage11;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button button9;
        public System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button button10;
        public System.Windows.Forms.TextBox textBox8;
        public System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        public System.Windows.Forms.ListView listView2;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
    }
}