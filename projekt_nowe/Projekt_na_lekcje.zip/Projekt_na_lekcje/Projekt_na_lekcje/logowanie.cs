﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Projekt_na_lekcje
{
    public partial class logowanie : Form
    {

        int counter = 0;
        string line;
        
        
        public logowanie()
        {
            InitializeComponent();
        }
        
        private void button2_Click(object sender, EventArgs e)
        {
            ZapisywanieDanych();

        }

        private void l_zaloguj_Click(object sender, EventArgs e)
        {
                System.IO.StreamReader file = new System.IO.StreamReader("Logowanie_i_Haslo.txt");
                while ((line = file.ReadLine()) != null)
                {
                    if (line.Contains(l_login.Text)&&line.Contains(l_haslo.Text))
                    {
                        Form2 P = new Form2();
                        this.Hide();
                        P.ShowDialog();
                        this.Close();
                        break;
                    }else if (!line.Contains(l_login.Text) && !line.Contains(l_haslo.Text))
                    {
                    MessageBox.Show("Nie ma takiego konta.");
                    }
                    counter++;
                    
                }
                file.Close();
                
            
           
        }
        

        private void l_login_TextChanged(object sender, EventArgs e)
        {

        }

        private void l_haslo_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void ZapisywanieDanych(){

            if (!File.Exists("Logowanie_i_Haslo.txt"))
            {
                File.Create("Logowanie_i_Haslo.txt").Close();
            }else{
                zarejestrujcs z = new zarejestrujcs();
                this.Hide();
                z.ShowDialog();
                this.Close();
            }

            

             
        }
    }
}
