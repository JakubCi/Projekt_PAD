﻿
namespace Projekt_na_lekcje
{
    partial class zarejestrujcs
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.z_zarejestruj = new System.Windows.Forms.Button();
            this.z_haslo = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.z_login = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.z_imie = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.z_mezczyzna = new System.Windows.Forms.RadioButton();
            this.z_kobieta = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // z_zarejestruj
            // 
            this.z_zarejestruj.Location = new System.Drawing.Point(525, 275);
            this.z_zarejestruj.Name = "z_zarejestruj";
            this.z_zarejestruj.Size = new System.Drawing.Size(149, 40);
            this.z_zarejestruj.TabIndex = 0;
            this.z_zarejestruj.Text = "zarejestruj się";
            this.z_zarejestruj.UseVisualStyleBackColor = true;
            this.z_zarejestruj.Click += new System.EventHandler(this.button1_Click);
            // 
            // z_haslo
            // 
            this.z_haslo.Location = new System.Drawing.Point(341, 152);
            this.z_haslo.Name = "z_haslo";
            this.z_haslo.Size = new System.Drawing.Size(178, 22);
            this.z_haslo.TabIndex = 9;
            this.z_haslo.TextChanged += new System.EventHandler(this.z_haslo_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(119, 152);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(121, 17);
            this.label2.TabIndex = 8;
            this.label2.Text = "Podaj swoje hasło";
            // 
            // z_login
            // 
            this.z_login.Location = new System.Drawing.Point(341, 105);
            this.z_login.Name = "z_login";
            this.z_login.Size = new System.Drawing.Size(178, 22);
            this.z_login.TabIndex = 7;
            this.z_login.TextChanged += new System.EventHandler(this.z_login_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(119, 108);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(109, 17);
            this.label1.TabIndex = 6;
            this.label1.Text = "Podaj swój login";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(119, 218);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(113, 17);
            this.label3.TabIndex = 12;
            this.label3.Text = "Podaj swoją płeć";
            // 
            // z_imie
            // 
            this.z_imie.Location = new System.Drawing.Point(341, 62);
            this.z_imie.Name = "z_imie";
            this.z_imie.Size = new System.Drawing.Size(178, 22);
            this.z_imie.TabIndex = 11;
            this.z_imie.TextChanged += new System.EventHandler(this.z_imie_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(119, 65);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(112, 17);
            this.label4.TabIndex = 10;
            this.label4.Text = "Podaj swoje imię";
            // 
            // z_mezczyzna
            // 
            this.z_mezczyzna.AutoSize = true;
            this.z_mezczyzna.Location = new System.Drawing.Point(22, 25);
            this.z_mezczyzna.Name = "z_mezczyzna";
            this.z_mezczyzna.Size = new System.Drawing.Size(99, 21);
            this.z_mezczyzna.TabIndex = 13;
            this.z_mezczyzna.TabStop = true;
            this.z_mezczyzna.Text = "Mężczyzna";
            this.z_mezczyzna.UseVisualStyleBackColor = true;
            this.z_mezczyzna.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // z_kobieta
            // 
            this.z_kobieta.AutoSize = true;
            this.z_kobieta.Location = new System.Drawing.Point(22, 61);
            this.z_kobieta.Name = "z_kobieta";
            this.z_kobieta.Size = new System.Drawing.Size(77, 21);
            this.z_kobieta.TabIndex = 14;
            this.z_kobieta.TabStop = true;
            this.z_kobieta.Text = "Kobieta";
            this.z_kobieta.UseVisualStyleBackColor = true;
            this.z_kobieta.CheckedChanged += new System.EventHandler(this.z_kobieta_CheckedChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.z_mezczyzna);
            this.groupBox1.Controls.Add(this.z_kobieta);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox1.Location = new System.Drawing.Point(319, 193);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 100);
            this.groupBox1.TabIndex = 15;
            this.groupBox1.TabStop = false;
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(12, 275);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(104, 40);
            this.button1.TabIndex = 16;
            this.button1.Text = "Cofnij";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // zarejestrujcs
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(686, 326);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.z_imie);
            this.Controls.Add(this.z_login);
            this.Controls.Add(this.z_haslo);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.z_zarejestruj);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Name = "zarejestrujcs";
            this.Text = "zarejestrujcs";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button z_zarejestruj;
        private System.Windows.Forms.TextBox z_haslo;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox z_login;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox z_imie;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.RadioButton z_mezczyzna;
        private System.Windows.Forms.RadioButton z_kobieta;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button1;
    }
}