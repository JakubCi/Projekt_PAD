﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace Projekt_na_lekcje
{
    public partial class Form2 : Form
    {
        decimal BudzetiNT;

        public Form2()
        {
            InitializeComponent();
            Wykres_Wydatki.Series["Wydatki"].Points.AddXY("", 100);
            Wykres_Wydatki.Series["Wydatki"].Points.AddXY("", 0);
            Wykres_Wydatki.Series["Wydatki"].Points.AddXY("", 0);
            Wykres_Wydatki.Series["Wydatki"].Points.AddXY("", 0);
            Wykres_Wydatki.Series["Wydatki"].Points.AddXY("", 0);

            
        }


        private void b_oszczednosci_Click(object sender, EventArgs e)
        {


        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {
            
            
        }

        private void tabPage2_Click(object sender, EventArgs e)
        {

           
        }

        private void tabPage3_Click(object sender, EventArgs e)
        {

            
        }

        private void tabPage2_Click_1(object sender, EventArgs e)
        {
            
        }

        private void tabPage3_Click_1(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Program.czy_prywatna = true;
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            Program.czy_prywatna = false;
        }

        private void tabPage6_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_2(object sender, EventArgs e)
        {
                Obliczanie();
        }

        private void k_ulga_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void k_koszty_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void k_kwota_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void k_zl_TextChanged(object sender, EventArgs e)
        {

        }

        private void Obliczanie(){
            float kwota = 0;
            float PPK = 0;
            float PPK1 = 0;
            float KosztUzyskPrzy = 250;
            float PodatekNal = 0;
            float kwotaUmowna =0;
            float kwotaDoOdjecia = 0;
            float skladkaZdrow = 0;
            

            kwota =  float.Parse(k_zl.Text);
            if(k_kwota.SelectedIndex > -1){
               
                if(k_kwota.SelectedIndex == 0){
                    KosztUzyskPrzy = 250;
                }else{
                    KosztUzyskPrzy = 300;
                }
            }else{
                MessageBox.Show("Nie Podałeś Kosztów!");
            }

   


    //Składki na ubezpieczenia
        kwotaDoOdjecia = kwota * 0.0976f;
        kwotaDoOdjecia += kwota * 0.015f;
        kwotaDoOdjecia += kwota * 0.0245f;



    //Składka zdrowotna


        skladkaZdrow = kwota - kwotaDoOdjecia;
        skladkaZdrow = (float)Math.Round(skladkaZdrow, 2);
        skladkaZdrow = skladkaZdrow * 0.09f;
        skladkaZdrow = (float)Math.Round(skladkaZdrow, 2);

    //PPK

        PPK = kwota * 0.02f;
        PPK1 = kwota * 0.015f;


    //Zaliczka na podatek dochodowy
        kwotaUmowna = kwota - kwotaDoOdjecia + PPK1 - KosztUzyskPrzy;



        if (kwota < 120000)
        {
            PodatekNal = kwotaUmowna * 0.17f;
            PodatekNal -= 425;

            PodatekNal = (float)Math.Floor(PodatekNal);
        }

      

    // Ustalenie wynagrodzenia


        kwota = kwota - kwotaDoOdjecia - skladkaZdrow - PPK - PodatekNal;
        MessageBox.Show(Convert.ToString(kwota));

    }



        
        private void vat_button_Click(object sender, EventArgs e)
        {
            double wynik,wynik2,vat;
            if (vat_kwota.SelectedIndex == 1)
            {
                switch (vat_stawka.SelectedIndex)
                {
                    case 0:{
                            wynik = Convert.ToDouble(vat_zl.Text) * 0.03 ;
                            vat = ((wynik + Convert.ToDouble(vat_zl.Text))- Convert.ToDouble(vat_zl.Text));
                            label9.Text = "Podatek vat: " + vat +"\n"+ "Kwota brutto: " +(wynik+ Convert.ToDouble(vat_zl.Text));
                        }break;
                    case 1:
                        {
                            
                            wynik = Convert.ToDouble(vat_zl.Text) * 0.05;
                            vat = ((wynik + Convert.ToDouble(vat_zl.Text)) - Convert.ToDouble(vat_zl.Text));
                            label9.Text = "Podatek vat: " + vat +"\n"+ "Kwota brutto: " +(wynik + Convert.ToDouble(vat_zl.Text));
                        }
                        break;
                    case 2:
                        {
                            
                            wynik = Convert.ToDouble(vat_zl.Text) * 0.07;
                            vat = ((wynik + Convert.ToDouble(vat_zl.Text)) - Convert.ToDouble(vat_zl.Text));
                            label9.Text = "Podatek vat: " + vat + "\n" + "Kwota brutto: " + (wynik + Convert.ToDouble(vat_zl.Text));
                        }
                        break;
                    case 3:
                        {
                            
                            wynik = Convert.ToDouble(vat_zl.Text) * 0.08;
                            vat = ((wynik + Convert.ToDouble(vat_zl.Text)) - Convert.ToDouble(vat_zl.Text));
                            label9.Text = "Podatek vat: " + vat + "\n" + "Kwota brutto: " + (wynik + Convert.ToDouble(vat_zl.Text));
                        }
                        break;
                    case 4:
                        {
                            
                            wynik = Convert.ToDouble(vat_zl.Text) * 0.22;
                            vat = ((wynik + Convert.ToDouble(vat_zl.Text)) - Convert.ToDouble(vat_zl.Text));
                            label9.Text = "Podatek vat: " + vat + "\n" + "Kwota brutto: " + (wynik + Convert.ToDouble(vat_zl.Text));
                        }
                        break;
                    case 5:
                        {
                            
                            wynik = Convert.ToDouble(vat_zl.Text) * 0.23;
                            vat = ((wynik + Convert.ToDouble(vat_zl.Text)) - Convert.ToDouble(vat_zl.Text));
                            label9.Text = "Podatek vat: " + vat + "\n" + "Kwota brutto: " + (wynik + Convert.ToDouble(vat_zl.Text));
                        }
                        break;

                }
            }
            else if (vat_kwota.SelectedIndex == 0)
            {
                switch (vat_stawka.SelectedIndex)
                {
                    
                    case 0:
                        {
                            wynik = Convert.ToDouble(vat_zl.Text) / 1.03 ;
                            wynik2 = Convert.ToDouble(vat_zl.Text) * 0.03;
                            vat = Convert.ToDouble(vat_zl.Text)- (float)Math.Round((decimal)wynik, 2);
                            label9.Text = "Podatek vat: " + Math.Round(vat,2) + "\n" + "Kwota netto: "+ Convert.ToString((float)Math.Round((decimal)wynik, 2));
                        }
                        break;
                    case 1:
                        {
                            wynik2 = Convert.ToDouble(vat_zl.Text) * 0.05;
                            wynik = Convert.ToDouble(vat_zl.Text) / 1.05 ;
                            vat = Convert.ToDouble(vat_zl.Text) - (float)Math.Round((decimal)wynik, 2);
                            label9.Text = "Podatek vat: " + Math.Round(vat, 2) + "\n" + "Kwota netto: " + Convert.ToString((float)Math.Round((decimal)wynik, 2));
                        }
                        break;
                    case 2:
                        {
                            wynik2 = Convert.ToDouble(vat_zl.Text) * 0.07;
                            wynik = Convert.ToDouble(vat_zl.Text) / 1.07 ;
                            vat = Convert.ToDouble(vat_zl.Text) - (float)Math.Round((decimal)wynik, 2);
                            label9.Text = "Podatek vat: " + Math.Round(vat, 2) + "\n" + "Kwota netto: " + Convert.ToString((float)Math.Round((decimal)wynik, 2));
                        }
                        break;
                    case 3:
                        {
                            wynik2 = Convert.ToDouble(vat_zl.Text) * 0.08;
                            wynik = Convert.ToDouble(vat_zl.Text) / 1.08 ;
                            vat = Convert.ToDouble(vat_zl.Text) - (float)Math.Round((decimal)wynik, 2);
                            label9.Text = "Podatek vat: " + Math.Round(vat, 2) + "\n" + "Kwota netto: " + Convert.ToString((float)Math.Round((decimal)wynik, 2));
                        }
                        break;
                    case 4:
                        {
                            wynik2 = Convert.ToDouble(vat_zl.Text) * 0.22;
                            wynik = Convert.ToDouble(vat_zl.Text) / 1.22 ;
                            vat = Convert.ToDouble(vat_zl.Text) - (float)Math.Round((decimal)wynik, 2);
                            label9.Text = "Podatek vat: " + Math.Round(vat, 2) + "\n" + "Kwota netto: " + Convert.ToString((float)Math.Round((decimal)wynik, 2));
                        }
                        break;
                    case 5:
                        {
                            wynik2 = Convert.ToDouble(vat_zl.Text) * 0.23;
                            wynik = Convert.ToDouble(vat_zl.Text) / 1.23 ;
                            vat = Convert.ToDouble(vat_zl.Text) - (float)Math.Round((decimal)wynik, 2);
                            label9.Text = "Podatek vat: " + Math.Round(vat, 2) + "\n" + "Kwota netto: " + Convert.ToString((float)Math.Round((decimal)wynik, 2));
                        }
                        break;

                }
            }
        }

        private void vat_stawka_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void vat_kwota_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void vat_zl_TextChanged(object sender, EventArgs e)
        {

        }

        private void zarobki_TextChanged(object sender, EventArgs e)
        {

            
        }

        private void ile_wydales_TextChanged(object sender, EventArgs e)
        {

        }
        /*        
                int w = 0;
                int wydatki = 0;
                int Zarobki = 0;
                int ilewydales;
                int hajs;
                int zmienna;*/
        decimal Wydatki_Pracownicy;
        private void button2_Click_2(object sender, EventArgs e)
        {
           Aktualizuj();
            #region staryKod
            /*
             if (zarobki.Text=="")
             {
                 ilewydales=Convert.ToInt32(ile_wydales.Text);
                 Zarobki = Zarobki + ilewydales;
                 w = hajs - wydatki;
                 p_wydatki_miesieczne.Text = tekst + Zarobki;
                 p_przychod_miesieczny.Text = tekst + w;
            MessageBox.Show("Musisz wpisać swoje zarobki.");
                
            }
            else if (ile_wydales.Text == "")
            {
                hajs = Convert.ToInt32(zarobki.Text);
                p_przychod_miesieczny.Text = tekst + Zarobki;
                
                ilewydales = 0;
                MessageBox.Show("Nie wpisałeś ile dziś wydałeś!");
            }
            else
            {     
                ilewydales=Convert.ToInt32(ile_wydales.Text);
                Zarobki = Zarobki + ilewydales;
                hajs = Convert.ToInt32(zarobki.Text);
                p_wydatki_miesieczne.Text = tekst+Zarobki;
                zmienna = Convert.ToInt32(p_wydatki_miesieczne.Text);
                w = hajs - zmienna;
                p_przychod_miesieczny.Text = tekst+w;
                MessageBox.Show("Poprawnie dodałeś dane.");
            }
            ile_wydales.Text = "";
            */
            #endregion
        }

     
        private void button3_Click_1(object sender, EventArgs e)
        {
            BudzetiNT = Convert.ToDecimal(Budzet.Text);
            /*
            MessageBox.Show("Przychód miesięczny wynosi: " + p_przychod_miesieczny.Text + "\nWydałeś w tym miesiącu: " + p_wydatki_miesieczne.Text);
            w = 0;
            hajs = 0;
            zmienna = 0;
            wydatki = 0;
            Zarobki = 0;
            ilewydales = 0;
            p_wydatki_miesieczne.Text = "";
            p_przychod_miesieczny.Text = "";
            W_Nieplanowane.Text = "";
            */
        }

        private void label15_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void Wykres_Wydatki_Click(object sender, EventArgs e)
        {

        }

        private void Budzet_TextChanged(object sender, EventArgs e)
        {

        }

        public void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        { 
            groupBox1.Visible = true;
            groupBox2.Visible = false;
        }

        private void button6_Click(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {
            dodajpracownika1(d_imie.Text,d_nazwisko.Text,d_wynagrodzenie.Text,d_posada.Text);
           Aktualizuj();
        }

        

        private void button5_Click(object sender, EventArgs e)
        {   
            groupBox2.Visible = true;
            groupBox1.Visible = false;
            
        }

        private void button8_Click(object sender, EventArgs e)
        {
            UsunPracownika();
            Aktualizuj();
        }
        int index =0;
        public void dodajpracownika1(string a,string b,string c,string d)
        {
            
            string i, n, w, p,k;
            i = a.ToString();
            n = b.ToString();
            w = d.ToString();
            p = c.ToString();
            k = index.ToString();
            index=index+1;
            

            
            ListViewItem item2 = new ListViewItem(i);
            
            // add items.
            item2.SubItems.Add(n);
            item2.SubItems.Add(w);
            item2.SubItems.Add(p);
            item2.SubItems.Add(k);
            listView1.Items.Add(item2);
            Wydatki_Pracownicy = Wydatki_Pracownicy + Convert.ToDecimal(c.ToString());
            




        }

        public void UsunPracownika()
        {
           

            ListViewItem item = listView1.FindItemWithText(textBox4.Text);
            Wydatki_Pracownicy = Wydatki_Pracownicy - Convert.ToDecimal(item.SubItems[3].Text.ToString());
            // Removes the first item in the list.
            listView1.Items.Remove(item);
            
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }



        public void Aktualizuj(){
             BudzetiNT = Convert.ToInt32(Budzet.Text);
            decimal Wydatki_Nieplanowane = Convert.ToDecimal(W_Nieplanowane.Text);
           
            decimal Wydatki_Sprzet = Convert.ToDecimal(W_Sprzet.Text);
            decimal Wydatki_Stale = Convert.ToDecimal(W_stale.Text);

            decimal P_Niepla = (Wydatki_Nieplanowane / BudzetiNT) * 100;
            decimal P_Praco = (Wydatki_Pracownicy / BudzetiNT) * 100;
            decimal P_Sprzet = (Wydatki_Sprzet / BudzetiNT) * 100;
            decimal P_Stale = (Wydatki_Stale / BudzetiNT) * 100;
            P_Niepla = Math.Round(P_Niepla, 2);
            P_Praco = Math.Round(P_Praco, 2);
            P_Sprzet = Math.Round(P_Sprzet, 2);
            P_Stale = Math.Round(P_Stale, 2);

            decimal Reszta = P_Niepla+P_Praco+P_Sprzet+P_Stale;
            Reszta = 100 - Reszta;
            Reszta = Math.Round(Reszta, 2);





            Wykres_Wydatki.Series["Wydatki"].Points[0].SetValueXY("Wydatki Nieplanowane", P_Niepla);
            Wykres_Wydatki.Series["Wydatki"].Points[1].SetValueXY("Wydatki na pracowników", P_Praco);
            Wykres_Wydatki.Series["Wydatki"].Points[2].SetValueXY("Wydatki na Sprzęt", P_Sprzet);
            Wykres_Wydatki.Series["Wydatki"].Points[3].SetValueXY("Wydatki Stałe", P_Stale);
            Wykres_Wydatki.Series["Wydatki"].Points[4].SetValueXY("Pozostałe Pieniądze" + Reszta + "%", Reszta);

            decimal Poz_P = (Reszta / 100) * BudzetiNT;
            Poz_P = Math.Round(Poz_P, 2);
            Pozostale_P.Text = Convert.ToString(Poz_P+"zł");
        }

        private void button12_Click(object sender, EventArgs e)
        {
            groupBox3.Visible = false;
            groupBox4.Visible = true;
//dodaj
        }

        private void button11_Click(object sender, EventArgs e)
        {
            groupBox3.Visible = true;
            groupBox4.Visible = false;
//usun
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
//numer
        }
        //usun 
        private void button9_Click(object sender, EventArgs e)
        {
            UsunProdukt();
        }

        private void button10_Click(object sender, EventArgs e)
        {

            DodajProduktr(textBox9.Text, textBox8.Text);
        }
//nazwa
        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }
//cena
        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }
        int index2 = 0;
        public void DodajProduktr(string a,string b)
        {
            
            string i, n,k;
            i = a.ToString();
            n = b.ToString();
            k = index2.ToString();
            index2=index2+1;

            
            ListViewItem item3 = new ListViewItem(i);
            
            // add items.
            item3.SubItems.Add(n);
            item3.SubItems.Add(k);
            listView2.Items.Add(item3);
        }

        public void UsunProdukt()
        {
           

            ListViewItem item = listView2.FindItemWithText(textBox5.Text);
            // Removes the first item in the list.
            listView2.Items.Remove(item);
            
        }
        
    }
}
